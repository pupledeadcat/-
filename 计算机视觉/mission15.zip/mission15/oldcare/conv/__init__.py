from .minivggnet import MiniVGGNet
