import cv2
import numpy as np
videoname='video.mp4'
fourcc = cv2.VideoWriter_fourcc('M', 'P', '4', '2')# 为保存视频做准备，构建了一个对象，其中１０为帧率，自己可按照需要修改
out=cv2.VideoWriter(videoname,fourcc,10,(640,480))
cap=cv2.VideoCapture(0)
while(1):
    ret,frame=cap.read()   #get frame
    #cv2.imshow("xiaorun",frame)
    cv2.imwrite('video.jpg', frame)
    #out.write(frame)
    if cv2.waitKey(1)&0xFF==ord('q')or ret==False:
        break
cap.release()
cv2.destroyAllwindows()
