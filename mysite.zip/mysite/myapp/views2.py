import json
import os

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.utils.timezone import now
import datetime
from sympy import false

from myapp.models import SysUser,EventInfo,EmployeeInfo,OldpersonInfo,VolunteerInfo

# Create your views here.

# 新增工作人员信息
def add_employee(request):
    name = request.session.get('name')
    if request.method == "POST":
        employee_name = request.POST.get('name')
        sex = request.POST.get('sex')
        id_card = request.POST.get('id')
        birthday = request.POST.get('birth')
        hiredate = request.POST.get('hiredate')

        phone = request.POST.get('phone')
        bz = request.POST.get('bz')

        myFile = request.FILES.get("f")  # 获取上传的文件，如果没有文件，则默认为None
        if not myFile:
            message = '请上传头像'
            return render(request, 'add_old.html', {'name': name, 'message': message})
        filename = '工作人员头像/' + employee_name + phone + '.jpg'
        path = os.path.join('static/', filename)
        destination = open(path, 'wb+')  # 打开特定的文件进行二进制的写操作
        for chunk in myFile.chunks():  # 分块写入文件
            destination.write(chunk)
        destination.close()

        uid = request.session.get('uid')

        EmployeeInfo.objects.create(username=employee_name, gender=sex, phone=phone, profile_photo=filename,
                                    id_card=id_card, birthday=birthday, hire_date=hiredate,
                                    description=bz, createby=uid, created=now(), remove=0)
        message = '创建成功'

        return render(request, 'add_employee.html', {'name': name, 'message': message})
    return render(request, 'add_employee.html', {'name': name})


# 工作人员信息管理
def employees_info(request):
    name = request.session.get('name')
    employees = EmployeeInfo.objects.filter(remove=0)
    return render(request, 'employees_info.html', {'name': name, 'employees': employees})


# 查看工作人员详细信息
def employee_detail(request):
    id = request.GET['id']
    employee = EmployeeInfo.objects.get(id=id)
    name = request.session.get('name')

    return render(request, 'employee_detail.html', {'name': name, 'employee': employee})


# 新增义工信息
def add_volunteer(request):
    name = request.session.get('name')
    if request.method == "POST":
        volunteer_name = request.POST.get('name')
        sex = request.POST.get('sex')
        id_card = request.POST.get('id')
        birthday = request.POST.get('birth')
        indate = request.POST.get('indate')

        phone = request.POST.get('phone')
        bz = request.POST.get('bz')

        myFile = request.FILES.get("f")  # 获取上传的文件，如果没有文件，则默认为None
        if not myFile:
            message = '请上传头像'
            return render(request, 'add_volunteer.html', {'name': name, 'message': message})
        filename = '义工头像/' + volunteer_name + phone + '.jpg'
        path = os.path.join('static/', filename)
        destination = open(path, 'wb+')  # 打开特定的文件进行二进制的写操作
        for chunk in myFile.chunks():  # 分块写入文件
            destination.write(chunk)
        destination.close()

        uid = request.session.get('uid')

        VolunteerInfo.objects.create(name=volunteer_name, gender=sex, phone=phone, profile_photo=filename,
                                     id_card=id_card, birthday=birthday, checkin_date=indate,
                                     description=bz, createby=uid, created=now(), remove=0)
        message = '创建成功'

        return render(request, 'add_volunteer.html', {'name': name, 'message': message})
    return render(request, 'add_volunteer.html', {'name': name})


# 义工信息管理
def volunteers_info(request):
    name = request.session.get('name')
    volunteers = VolunteerInfo.objects.filter(remove=0)
    return render(request, 'volunteers_info.html', {'name': name, 'volunteers': volunteers})


# 查看义工详细信息
def volunteer_detail(request):
    id = request.GET['id']
    volunteer = VolunteerInfo.objects.get(id=id)
    name = request.session.get('name')

    return render(request, 'volunteer_detail.html', {'name': name, 'volunteer': volunteer})